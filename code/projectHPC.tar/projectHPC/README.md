This folder contains the code used to obtain our data and process it. Use submit_hastag.sh to read in all files of the hashtag folder in Lunchbox and submit_sentiment.sh for the sentiment folder.
