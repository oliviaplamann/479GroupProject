#!/bin/bash

cat sentiment_summary*.csv > sentiment_day.csv
