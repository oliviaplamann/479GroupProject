#!/bin/bash

cat sentiment_summary*.csv > sentiment_month.csv
cat sentiment_summary_2020*.csv > sentiment_month_2020.csv
cat sentiment_summary_2021*.csv > sentiment_month_2021.csv
cat sentiment_summary_2022*.csv > sentiment_month_2022.csv
